<script type="text/javascript"> 

	window.onload = function() { 
		
		animateprogress("#progreso_1",91);
		
	} 	
	document.querySelector ("#boton_1").addEventListener ("click", function() { 
		animateprogress("#progreso_1",91);   
	});
</script>